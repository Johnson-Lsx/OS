#include"pstree.h"
int main(int argc, char* argv[])
{
	int *nr;
	struct prinfo *tree;
	nr = (int*) calloc(1,sizeof(int));
	tree = (struct prinfo*) calloc(500,sizeof(struct prinfo));
	int i = syscall(356,tree,nr);
	if(i == 0)
	printf("ptree has been called!The Ptree has %d entries\n",*nr);
	else
	printf("system call failed!\n");
	printTree(tree,nr);
	return 0;
}
