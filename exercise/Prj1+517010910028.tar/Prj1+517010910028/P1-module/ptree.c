#include<linux/module.h>
#include<linux/kernel.h>
#include <linux/slab.h>
#include<linux/init.h>
#include<linux/sched.h>
#include<linux/unistd.h>
#include<linux/types.h>
MODULE_LICENSE("Dual BSD/GPL");
#define __NR_ptree 356

struct prinfo
{
	int idnt;				//indent, used in printing the tree
	pid_t parent_pid; 		//process id of parent
	pid_t pid; 				//process id
	pid_t first_child_pid; 	//pid of youngest child
	pid_t next_sibling_pid; //pid of older sibling
	long state; 			//current state of process
	long uid; 				//user id of process owener
	char comm[64]; 			//name of program executed	
};

//DFS function that puts the information of processes into the prinfo struct buffer 
//and count the entries in the buffer
static void DFS1(struct task_struct *task, struct prinfo *buf, int *nr, int indent)
  {
	struct list_head *list;//help to traverse the processes tree				
	struct task_struct* s; //point to the next sibling's task_struct of the current process
	struct task_struct *c; //point to the first child's task_struct of the current process
	if(task == NULL)	   //if the root is NULL, return					
		return;
	(buf+*nr)->idnt = indent;//set up the indent for the current process
	(buf+*nr)->pid = task->pid;//get the pid
	(buf+*nr)->state = task->state;//get the state
	(buf+*nr)->uid = task->cred->uid;//get the uid
	strcpy((buf+*nr)->comm,task->comm);//get the comm
	if(task != &init_task)			   //if has parent
		(buf+*nr)->parent_pid = task->parent->pid;
	else
		(buf+*nr)->parent_pid = 0;
	s = list_entry(task->sibling.next,struct task_struct,sibling);
	c = list_entry(task->children.next,struct task_struct,sibling);
	if(task->children.next != &task->children)//if has child
	{
		(buf+*nr)->first_child_pid = c->pid;//get the pid of the first child
		if(s->pid != task->parent->pid && s->pid != 1)//if has next sibling
			(buf+*nr)->next_sibling_pid = s->pid;//get the pid of next sibling
		else
			(buf+*nr)->next_sibling_pid = 0;//else, set the pid of next sibling to 0
	}
	else
	{
		(buf + *nr)->first_child_pid = 0; //set the pid of first child to 0
		if(s->pid != task->parent->pid && s->pid != 1)//if has sibling
                	(buf+*nr)->next_sibling_pid = s->pid;
                else
                        (buf+*nr)->next_sibling_pid = 0;//else, set to 0

	}
	*nr = *nr + 1;//point to the next buffer
	for(list = task->children.next;list != &task->children;list = list->next)
	{
		//call DFS1 recursively
		DFS1(list_entry(list,struct task_struct,sibling),buf,nr,indent+1);
	}

  }

//DFS function used to print the pstree in kernel, which can only be viewed by 'dmesg' command
static void DFS(struct list_head *list, struct task_struct *task,int indent)
{
	struct task_struct *temp;
	int i = 1;
	temp = task;
	if((temp->children.next) != &(temp->children))
	{
		for(i = 1;i <= indent;++i)
		{
			printk("    ");
		}
		if(list_entry(temp->sibling.next,struct task_struct,sibling)->pid != temp->parent->pid && list_entry(temp->sibling.next,struct task_struct,sibling)->pid != 1)
			printk("%s,%d,%ld,%d,%d,%d,%d\n",task->comm,task->pid,task->state,task->parent->pid,list_entry(task->children.next,struct task_struct,sibling)->pid,list_entry(temp->sibling.next,struct task_struct,sibling)->pid,task->cred->uid);
		else
			printk("%s,%d,%ld,%d,%d,%d,%d\n",task->comm,task->pid,task->state,task->parent->pid,list_entry(task->children.next,struct task_struct,sibling)->pid,0,task->cred->uid);
			
	}
	else
	{
		for(i = 1;i <= indent;++i)
		{
			printk("    ");
		}
		if(list_entry(temp->sibling.next,struct task_struct,sibling)->pid != temp->parent->pid && list_entry(temp->sibling.next,struct task_struct,sibling)->pid != 1)
			printk("%s,%d,%ld,%d,%d,%d,%d\n",task->comm,task->pid,task->state,task->parent->pid,0,list_entry(temp->sibling.next,struct task_struct,sibling)->pid,task->cred->uid);
		else
			printk("%s,%d,%ld,%d,%d,%d,%d\n",task->comm,task->pid,task->state,task->parent->pid,0,0,task->cred->uid);
	}
	list_for_each(list,&(task->children))
	{
		temp = list_entry(list,struct task_struct,sibling);
		DFS(list,temp,indent+1);
	}
}

static int (*oldcall)(void);
static int ptree(struct prinfo *buf, int *nr)
{
	if(buf && nr)
	{
        	DFS1(&init_task,buf,nr,0);
	}
	return 0;
}

static int addsyscall_init(void)
{
	struct list_head *list;
	long *syscall = (long*)0xc000d8c4;
	oldcall = (int(*)(void))(syscall[__NR_ptree]);
	syscall[__NR_ptree] = (unsigned long)ptree;
	printk(KERN_INFO "moudle load!\n");
	read_lock(&tasklist_lock);
	DFS(list, &init_task,0);
	read_unlock(&tasklist_lock);
	return 0;
}

static void addsyscall_exit(void)
{
	long *syscall = (long*)0xc000d8c4;
	syscall[__NR_ptree] = (unsigned long)oldcall;
	printk(KERN_INFO "moudle exit!\n");
}

module_init(addsyscall_init);
module_exit(addsyscall_exit);
