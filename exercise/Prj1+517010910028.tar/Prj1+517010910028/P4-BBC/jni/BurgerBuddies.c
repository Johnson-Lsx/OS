#include"BurgerBuddies.h"

int main(int argc, char* argv[])
{
	int i = 0, cooks = 0, cashiers = 0, customers = 0, rack_size = 0;
	pthread_t *cook_tid, *cashier_tid, *customer_tid;
	pthread_attr_t attr;

	//check the number of parameters
	if(argc != 5)
	{
		fprintf(stderr,"There should be 4 parameters!\n");
		return -1;
	}
	//check the value of parameters
	for(i = 1;i < argc;++i)
	{
		if(atoi(argv[i])  < 0)
		{
			fprintf(stderr,"All parameters should be Nonnegative integer numbers!\n");
			return -1;
		}
	}

	cooks = atoi(argv[1]);		//the number of cooks
	cashiers = atoi(argv[2]);	//the number of cashiers
	customers = atoi(argv[3]);	//the number of customers
	rack_size = atoi(argv[4]);	//the size of the rack
	cook_tid = (pthread_t *)calloc(cooks+1,sizeof(pthread_t));			//creat a pthread_t array, the size is the same as $cooks
	cashier_tid = (pthread_t *)calloc(cashiers+1,sizeof(pthread_t));	//creat a pthread_t array, the size is the same as $cashiers
	customer_tid = (pthread_t *)calloc(customers+1,sizeof(pthread_t));	//creat a pthread_t array, the size is the same as $customers
	//initialize the semaphores
	sem_init(&mutex,1,1);				  //used to protect the visit to rack
	sem_init(&mutex1,1,1);				  //used to guarantee the arriving order of customers
	sem_init(&num_empty, 1, rack_size);	  //used to represent how many  burgers the rack can hold currently
	sem_init(&num_full, 1, 0);			  //used to represent how many burgers are available currently
	sem_init(&num_cashiers, 1, cashiers); //used to  represent how many cashiers can serve the customers currently
	sem_init(&num_customers, 1, 0);		  //used to represent how many customers are waiting for the service currently
	sem_init(&num_burgers, 1, 0);		  //binary semaphores, used to guarantee that a customer leave only after getting the burger
	pthread_attr_init(&attr);			  //get the default attrbutes
	printf("Cook [%d], Cashiers [%d], Customers [%d]\nBegin run.\n",cooks,cashiers,customers);
	srand((int)time(0));				  //set up the seed for rand()

	//creat threads
	for(i = 1;i <= cooks;++i)
	{
		pthread_create(&cook_tid[i], &attr, cook, i);
	}
	for(i = 1;i <= cashiers;++i)
	{
		pthread_create(&cashier_tid[i], &attr, cashier, i);
	}
	for(i = 1;i <= customers;++i)
	{
		pthread_create(&customer_tid[i], &attr, customer, i);
	}

	//wait for the threads to exit
	for(i = 1;i <= customers;++i)
	{
		pthread_join(customer_tid[i], NULL);
	}
	//if all customers have been servered, we can end the process
	for(i = 1;i <= cooks;++i)
	{
		pthread_kill(cook_tid[i], SIGKILL);
	}
	for(i = 1;i <= cashiers;++i)
	{
		pthread_kill(cashier_tid[i], SIGKILL);
	}
	
	for(i = 1;i <= cooks;++i)
	{
		pthread_join(cook_tid[i], NULL);
	}
	for(i = 1;i <= cashiers;++i)
	{
		pthread_join(cashier_tid[i], NULL);
	}

	//free the memory
	sem_destroy(&mutex);
	sem_destroy(&num_empty);
	sem_destroy(&num_full);
	sem_destroy(&num_cashiers);
	sem_destroy(&num_customers);
	sem_destroy(&num_burgers);
	return 0;
}
