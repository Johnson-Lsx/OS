#ifndef HELLOHEADER_H_
#define HELLOHEADER_H_
#include <stdio.h>
#include<stdlib.h>
#include<time.h>
#include <unistd.h>
#include<pthread.h>
#include<semaphore.h>

typedef enum __bool { false = 0, true = 1, } bool;
#define cook_speed 5  //how many time need to make a burger
#define MAX 20        //used to bound the time a customer come for service
sem_t mutex, mutex1, num_empty, num_full, num_cashiers, num_customers, num_burgers; //some semaphores

void *cook(void *param)
{
  int cook_id = param;         //assign the id
  do{
    sleep(cook_speed);         //make a burger
    sem_wait(&num_empty);      //to see if the rack can hold one burger
    sem_wait(&mutex);          //grap the lock
    printf("cook [%d] make a burger.\n",cook_id);//put the burger into the rack
    sem_post(&mutex);          //release the lock
    sem_post(&num_full);       //the number of available burgers now increase 1
 } while(true);
  pthread_exit(0);
}

void *cashier(void *param)
{
  int cashier_id = param;     //assign the id
  do{
    sem_wait(&num_customers); //wait for a customer coming
    printf("cashier [%d] accepts an order.\n",cashier_id); //a customer comes to the cashier
    sem_wait(&num_full);      //see if there is a burger in the rack
    sem_wait(&mutex);         //grap the lock
    printf("cashier [%d] takes a burger to customor.\n",cashier_id);//get a burger from the rack
    sem_post(&mutex);         //release the lock
    sem_post(&num_empty);     //the rack can hold one more burger now
    sem_post(&num_burgers);   //the customer can get the burger and leave
  } while(true);
  pthread_exit(0);
}

void *customer(void *param)
{
  int customer_id = param;    //assign the id
  sleep(rand() % MAX);        //a customer can arrive at any time in range of (0, MAX)
  sem_wait(&mutex1);          //grap the lock
  printf("customer [%d] comes.\n",customer_id);
  sem_post(&mutex1);          //release the lock
  sem_post(&num_customers);   //the number of cutomers waiting for service increase 1
  sem_wait(&num_cashiers);    //see if there is a cashier ready to accept the order
  sem_wait(&mutex1);          //grap the lock
  sem_wait(&num_burgers);     //wait the cashier to bring a burger
  printf("customer [%d] leaves.\n",customer_id);//get the burger and leave
  sem_post(&mutex1);          //release the lock
  sem_post(&num_cashiers);    //the cashier can server the next customer
  pthread_exit(0);
}
#endif /*HELLOHEADER_H_*/
