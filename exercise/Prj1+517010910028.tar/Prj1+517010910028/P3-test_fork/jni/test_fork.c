#include"test_fork.h"
int main(int argc, char* argv[])
{
	pid_t pid;
	pid = fork();
	if(pid < 0)
	{
		printf("Fork failed!\n");
		return 1;
	}
	else
	{
		if(pid == 0)
		{
			printf("517010910028Child%d\n",getpid());
			execl("/data/misc/pstree","pstree",NULL);
		}
		else
		{
			wait(NULL);
			printf("517010910028Parent%d\n",getpid());
		}
	}
	return 0;
}
