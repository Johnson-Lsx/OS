### README

#### commands to compile and run each program

1. For problem 1, in the folder `P1-module`, open the terminal and type `make`, then the `ptree.ko` is the module needed. Use the command `adb push ptree.ko data\misc` to push the module onto `avd`. In another terminal, type `adb shell` to log in the `avd` as root user, type `cd data\misc` to enter the correct directory. Use the command `insmod ptree.ko` to install the module.
2. For problem 2, in the folder `P2-pstree/jni`, open the terminal and type `ndk-build`, then there will be two new created directories, `libs` and `obj`. In the terminal type `cd ../libs/armeabi` and next type `chmod +x pstree`, finally use the command `adb push pstree data/misc`. In another terminal, type `adb shell` and `cd data/misc`, to run the program, type `./pstree`.
3. For problem 3, in the folder `P3-test_fork/jni`, open the terminal and type `ndk-build`, then there will be two new created directories, `libs` and `obj`. In the terminal type `cd ../libs/armeabi` and next type `chmod +x test_fork`, finally use the command `adb push test_fork data/misc`. In another terminal, type `adb shell` and `cd data/misc`, to run the program, type `./test_fork`.
4. For problem 4, in the folder `P4-BBC/jni`, open the terminal and type `ndk-build`, then there will be two new created directories, `libs` and `obj`. In the terminal type `cd ../libs/armeabi` and next type `chmod +x BBC`, finally use the command `adb push BBC data/misc`. In another terminal, type `adb shell` and `cd data/misc`, to run the program, type `./BBC #Cooks #Cashiers #Customers #RackSize`.

#### running examples

1. For problem 2

   ```
   root@generic:/data/misc # ./pstree                                             
   ptree has been called!The Ptree has 67 entries
   swapper,0,0,0,1,0,0
       init,1,1,0,45,2,0
           ueventd,45,1,1,0,62,0
           logd,62,1,1,0,63,1036
           vold,63,1,1,0,69,0
           healthd,69,1,1,0,70,0
           lmkd,70,1,1,0,71,0
           servicemanager,71,1,1,0,72,1000
           surfaceflinger,72,1,1,0,74,1000
           qemud,74,1,1,0,77,0
           sh,77,1,1,0,78,2000
           adbd,78,1,1,390,79,0
               sh,390,1,78,1568,0,0
                   pstree,1568,0,390,0,0,0
           netd,79,1,1,0,80,0
           debuggerd,80,1,1,0,81,0
           rild,81,1,1,0,82,1001
           drmserver,82,1,1,0,83,1019
           mediaserver,83,1,1,0,84,1013
           installd,84,1,1,0,85,0
           keystore,85,1,1,0,86,1017
           main,86,1,1,228,90,0
               system_server,228,1,86,0,695,1000
               putmethod.latin,695,1,86,0,721,10032
               d.process.acore,721,1,86,0,735,10002
               m.android.phone,735,1,86,0,740,1001
               droid.launcher3,740,1,86,0,847,10007
               ndroid.systemui,847,1,86,0,867,10013
               d.process.media,867,1,86,0,932,10005
               droid.deskclock,932,1,86,0,990,10023
               ndroid.calendar,990,1,86,0,1009,10019
               viders.calendar,1009,1,86,0,1032,10001
               .android.dialer,1032,1,86,0,1066,10004
               gedprovisioning,1066,1,86,0,1088,10008
               m.android.email,1088,1,86,0,1103,10027
               ndroid.exchange,1103,1,86,0,1450,10029
               android.browser,1450,1,86,0,0,10017
           gatekeeperd,90,1,1,0,94,1000
           perfprofd,94,1,1,0,95,0
           fingerprintd,95,1,1,0,0,1000
       kthreadd,2,1,0,3,0,0
           ksoftirqd/0,3,1,2,0,6,0
           khelper,6,1,2,0,7,0
           sync_supers,7,1,2,0,8,0
           bdi-default,8,1,2,0,9,0
           kblockd,9,1,2,0,10,0
           rpciod,10,1,2,0,11,0
           kworker/0:1,11,1,2,0,12,0
           kswapd0,12,1,2,0,13,0
           fsnotify_mark,13,1,2,0,14,0
           crypto,14,1,2,0,25,0
           kworker/u:1,25,1,2,0,30,0
           mtdblock0,30,1,2,0,35,0
           mtdblock1,35,1,2,0,40,0
           mtdblock2,40,1,2,0,41,0
           binder,41,1,2,0,42,0
           deferwq,42,1,2,0,43,0
           kworker/u:2,43,1,2,0,44,0
           mmcqd/0,44,1,2,0,47,0
           jbd2/mtdblock0-,47,1,2,0,48,0
           ext4-dio-unwrit,48,1,2,0,53,0
           kworker/0:2,53,1,2,0,54,0
           jbd2/mtdblock1-,54,1,2,0,55,0
           ext4-dio-unwrit,55,1,2,0,60,0
           jbd2/mtdblock2-,60,1,2,0,61,0
           ext4-dio-unwrit,61,1,2,0,125,0
           kauditd,125,1,2,0,0,0
   
   ```

2. For problem 3

   ```
   root@generic:/data/misc # ./test_fork                                          
   517010910028Child1571
   ptree has been called!The Ptree has 69 entries
   swapper,0,0,0,1,0,0
       init,1,1,0,45,2,0
           ueventd,45,1,1,0,62,0
           logd,62,1,1,0,63,1036
           vold,63,1,1,0,69,0
           healthd,69,1,1,0,70,0
           lmkd,70,1,1,0,71,0
           servicemanager,71,1,1,0,72,1000
           surfaceflinger,72,1,1,0,74,1000
           qemud,74,1,1,0,77,0
           sh,77,1,1,0,78,2000
           adbd,78,1,1,390,79,0
               sh,390,1,78,1570,0,0
                   test_fork,1570,1,390,1571,0,0
                       pstree,1571,0,1570,0,0,0
           netd,79,1,1,0,80,0
           debuggerd,80,1,1,0,81,0
           rild,81,1,1,0,82,1001
           drmserver,82,1,1,0,83,1019
           mediaserver,83,1,1,0,84,1013
           installd,84,1,1,0,85,0
           keystore,85,1,1,0,86,1017
           main,86,1,1,228,90,0
               system_server,228,1,86,0,695,1000
               putmethod.latin,695,1,86,0,721,10032
               d.process.acore,721,1,86,0,735,10002
               m.android.phone,735,1,86,0,740,1001
               droid.launcher3,740,1,86,0,847,10007
               ndroid.systemui,847,1,86,0,867,10013
               d.process.media,867,1,86,0,932,10005
               droid.deskclock,932,1,86,0,990,10023
               ndroid.calendar,990,1,86,0,1009,10019
               viders.calendar,1009,1,86,0,1032,10001
               .android.dialer,1032,1,86,0,1066,10004
               gedprovisioning,1066,1,86,0,1088,10008
               m.android.email,1088,1,86,0,1103,10027
               ndroid.exchange,1103,1,86,0,1450,10029
               android.browser,1450,1,86,0,0,10017
           gatekeeperd,90,1,1,0,94,1000
           perfprofd,94,1,1,0,95,0
           fingerprintd,95,1,1,0,0,1000
       kthreadd,2,1,0,3,0,0
           ksoftirqd/0,3,1,2,0,6,0
           khelper,6,1,2,0,7,0
           sync_supers,7,1,2,0,8,0
           bdi-default,8,1,2,0,9,0
           kblockd,9,1,2,0,10,0
           rpciod,10,1,2,0,11,0
           kworker/0:1,11,1,2,0,12,0
           kswapd0,12,1,2,0,13,0
           fsnotify_mark,13,1,2,0,14,0
           crypto,14,1,2,0,25,0
           kworker/u:1,25,1,2,0,30,0
           mtdblock0,30,1,2,0,35,0
           mtdblock1,35,1,2,0,40,0
           mtdblock2,40,1,2,0,41,0
           binder,41,1,2,0,42,0
           deferwq,42,1,2,0,43,0
           kworker/u:2,43,1,2,0,44,0
           mmcqd/0,44,1,2,0,47,0
           jbd2/mtdblock0-,47,1,2,0,48,0
           ext4-dio-unwrit,48,1,2,0,53,0
           kworker/0:2,53,1,2,0,54,0
           jbd2/mtdblock1-,54,1,2,0,55,0
           ext4-dio-unwrit,55,1,2,0,60,0
           jbd2/mtdblock2-,60,1,2,0,61,0
           ext4-dio-unwrit,61,1,2,0,125,0
           kauditd,125,1,2,0,1569,0
           flush-31:1,1569,1,2,0,0,0
   517010910028Parent1570
   
   ```

3. For problem 4

   ```
   root@generic:/data/misc # ./BBC 2 4 10 5                                       
   Cook [2], Cashiers [4], Customers [10]
   Begin run.
   customer [3] comes.
   cashier [4] accepts an order.
   cook [2] make a burger.
   cook [1] make a burger.
   cashier [4] takes a burger to customor.
   customer [3] leaves.
   customer [7] comes.
   cashier [3] accepts an order.
   cashier [3] takes a burger to customor.
   customer [7] leaves.
   customer [6] comes.
   cashier [3] accepts an order.
   cook [2] make a burger.
   cashier [3] takes a burger to customor.
   customer [6] leaves.
   customer [1] comes.
   cook [1] make a burger.
   cashier [2] accepts an order.
   cashier [2] takes a burger to customor.
   customer [1] leaves.
   customer [10] comes.
   cashier [2] accepts an order.
   cook [2] make a burger.
   cashier [2] takes a burger to customor.
   customer [10] leaves.
   customer [4] comes.
   cook [1] make a burger.
   cashier [1] accepts an order.
   cashier [1] takes a burger to customor.
   customer [4] leaves.
   customer [5] comes.
   cashier [1] accepts an order.
   cook [2] make a burger.
   cashier [1] takes a burger to customor.
   customer [5] leaves.
   customer [2] comes.
   cashier [4] accepts an order.
   cook [1] make a burger.
   cashier [4] takes a burger to customor.
   customer [2] leaves.
   customer [9] comes.
   cashier [3] accepts an order.
   cook [2] make a burger.
   cashier [3] takes a burger to customor.
   customer [9] leaves.
   customer [8] comes.
   cashier [2] accepts an order.
   cook [1] make a burger.
   cashier [2] takes a burger to customor.
   customer [8] leaves.
   Killed 
   ```

   